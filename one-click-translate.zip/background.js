chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "translate") {
    chrome.tabs.executeScript({
      code: `
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = 'https://res.zvo.cn/translate/inspector_v2.js';
        head.appendChild(script);
      `
    });
  }
});