document.getElementById('translateBtn').addEventListener('click', function() {
  chrome.runtime.sendMessage({action: "translate"});
  window.close();
});